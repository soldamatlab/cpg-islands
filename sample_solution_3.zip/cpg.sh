#!/bin/bash

# this script should solve the assignment

python main.py "$@"

