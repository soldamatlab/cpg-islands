#!/bin/bash

# in this file put any commands necessary for compilation of your source codes

# eeh, actually, we do not need to compile Python
